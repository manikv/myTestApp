import { Component, OnInit } from '@angular/core';

import {NgbModal, NgbActiveModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from '../app.component';
import { flatten } from '@angular/compiler';
import { DraftsComponent } from '../drafts/drafts.component'
import { NotificationComponent } from '../notification/notification.component'

@Component({
  selector: 'app-alert-model',
  templateUrl: './alert-model.component.html',
  styleUrls: ['./alert-model.component.css']
})
export class AlertModelComponent implements OnInit {
shown:boolean;

  constructor(private modalService: NgbModal, public activeModal: NgbActiveModal) {}

  ngOnInit() {
    // this.modalReference.close();
    this.drafts();
  }
  
  drafts(){
    this.shown=true;
  }
  notification()
{
  this.shown=false;

}
}
