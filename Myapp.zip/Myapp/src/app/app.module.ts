import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AlertModelComponent } from './alert-model/alert-model.component';
// import { NgbModule, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalConfig, NgbModal, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { DraftsComponent } from './drafts/drafts.component';
import { NotificationComponent } from './notification/notification.component';
import { AppRoutingModule } from './app-routung.module';
import { PopoverModule } from "ngx-smart-popover";
// import { AgGridModule } from 'ag-grid-angular';
@NgModule({
  declarations: [
    AppComponent,
    AlertModelComponent,
    DraftsComponent,
    NotificationComponent
  ],
  imports: [
    BrowserModule,NgbModule,AppRoutingModule,PopoverModule
    //,AgGridModule.withComponents()
  ],
  providers: [NgbModalConfig, NgbModal],
  bootstrap: [AppComponent],
  entryComponents: [ AlertModelComponent ]
})
export class AppModule { }
