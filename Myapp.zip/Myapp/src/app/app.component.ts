import { Component } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertModelComponent } from './alert-model/alert-model.component'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(config: NgbModalConfig, private modalService: NgbModal) {
    
  }
  title = 'myTestApp';
  

  open(){
    const modalRef = this.modalService.open(AlertModelComponent);
    // modalRef.componentInstance.id = 10;
    // modalRef.result.then((result) => {
    //   console.log(result);
    // }).catch((error) => {
    //   console.log(error);
    // });
  }
}
