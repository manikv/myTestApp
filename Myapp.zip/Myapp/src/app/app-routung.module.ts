import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import { DraftsComponent } from './drafts/drafts.component';
import { NotificationComponent } from './notification/notification.component';

const routes: Routes = [
    { path: 'drafts', component: DraftsComponent },
    { path: 'notification', component: NotificationComponent },

]; 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }